import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-setting',
  templateUrl: './global-setting.component.html',
  styleUrls: ['./global-setting.component.scss']
})
export class GlobalSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
