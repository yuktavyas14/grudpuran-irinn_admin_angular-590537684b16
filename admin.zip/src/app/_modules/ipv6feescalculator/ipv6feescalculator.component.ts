import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ipv6feescalculator',
  templateUrl: './ipv6feescalculator.component.html',
  styleUrls: ['./ipv6feescalculator.component.scss']
})
export class Ipv6feescalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
