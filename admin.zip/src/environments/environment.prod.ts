export const environment = {
  production: true,
  APIEndpoint:'http://172.105.50.222:8080/irinn/',

  // APIEndpoint: window.location.origin +'/ixnixi/admin',
};
